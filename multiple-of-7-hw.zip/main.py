num=int(input("Enter a number:"))

if(num%7==0):
    print("It is a multiple of 7")
else:
    print("It is not a multiple of 7")