num=int(input("Enter your number:"))
if(num%2)==0:
    print("It is an even nember")
else:
    print("It is an odd number")