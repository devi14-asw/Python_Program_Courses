d={"abc":2,"xyz":3,"cse":4,"pqr":5,"asw":4}
print(d["asw"])

d={"asw":2,28:14,(13,14):4,"pqr":{1,2,8,4},"stu":4}
print(d)

#dataset
dataset={"name":"asw","age":19,"address":"xyz"}
d=[1,4,2,8]
print(d[3])

dataset={"name":"asw","age":19,"address":"xyz","pincode":19}
print(dataset["age"])
print(dataset["pincode"])

dataset={"name":"asw",(7,28):{1,4,3},"age":19,"address":"xyz","pincode":19}
print(dataset[(7,28)])
print(dataset["pincode"])
#value-can be any datatype
#key-string,int,tuple

#keys
dataset={"name":"asw",(7,28):{1,4,3},"age":19,"address":"xyz","pincode":19}
a=dataset.keys()
print(a)

#items
dataset={"name":"asw",(7,28):{1,4,3},"age":19,"address":"xyz","pincode":19}
a=dataset.items()
print(a)

#pop
dataset={"name":"asw",(7,28):{1,4,3},"age":19,"address":"xyz","pincode":19}
dataset.pop((7,28))
print(dataset)

#pop and popitem
dataset={"name":"asw",(7,28):{1,4,3},"age":19,"address":"xyz","pincode":19}
dataset.pop("address")
print(dataset)
dataset.popitem()
print(dataset)