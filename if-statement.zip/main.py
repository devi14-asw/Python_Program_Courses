n=int(input("Enter your mark:"))

if n>35 and n<80:
    print("Pass")
    print("Need to improve")
elif n>80:
    print("Pass and well performed")
else:
    print("Fail")