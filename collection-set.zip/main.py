#tuple
t=(1,2,2.8,'Devi')
print(t)

#typecaste
t=(1)
print(type(t))

t=(1,)
print(type(t))

#collection set
s={1,2,3,4,3,5,5,6}
print(s)

s={1,2,3,4,3,5,5,6}
s.add(8)
print(s)

s={1,2,3,4,3,5,5,6}
s1={'a','b','c'}
print(s1)

#remove
s={1,2,3,4,3,5,5,6}
s.remove(6)
print(s)

#add and remove unordered due to string
s={1,2,3,4,3,5,5,6}
s.add("name")
s.remove(3)
print(s)

#discard
s={1,2,3,4,3,5,5,6}
s.discard(5)
print(s)

#union 
s1={1,2,3,5,8,8}
s2={'a','s','w'}
s3=s1.union(s2)
print(s3)

#update
s1={1,2,7,9,9,5}
s2={'a','s','w'}
s2.update(s1)
print(s2)

#intersection
s1={1,3,6,8,7,6,5}
s2={'a','n','t','h',5,6,3}
s=s1.intersection(s2)
print(s)



