#step index
name='Devisri'
print(name[0:7:3])

#method
#upper
name='devisri'
a=name.upper()
print(a)

#lower
name='DEVISRI'
a=name.lower()
print(a)

#isupper
name="devisri"
a=name.isupper()
print(a)

#islower
name="DEVISRI"
a=name.islower()
print(a)

#capitalize
name="dEVISRI"
a=name.capitalize()
print(a)
