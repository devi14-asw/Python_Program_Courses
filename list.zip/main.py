#list
l=[28,14,'hi','ji']
l.insert(2,'fi')
print(l)

#pop
l=[28,14,'hi','ji']
l.insert(2,'fi')
l.pop(3)
print(l)

#sorted
l=[5,44,73,88,64]
l.sort()#ascending order
print(l)

#reversed
l=[5,44,73,88,64]
l.reverse()
print(l)
