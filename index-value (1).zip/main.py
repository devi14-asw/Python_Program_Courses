#finding index
name='Devisri'
a=name.index("e")
print(a)

name='Devisri'
a=name.index("vis")
print(a)

#swapcase
name='DEVIsri'
a=name.swapcase()
print(a)

#startswith
name='DEVIsri'
a=name.startswith("s")
print(a)

#endswith
name='devisri'
a=name.endswith("i")
print(a)

#collection list
l=[0.5,6,False,'Devi']
l[1]="a"
print(l[1])
print(l[0:2])
#step index
print(l[0:4:2])
print(len(l))

#append
l=[0.5,3,False,'Devi']
a=l.append(28)
print(l)
#insert
l=[0.5,3,False,'Devi']
l.insert(1,'a')
print(l)
